import cv2
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os


def calcular_histograma(canal, bins=256):
    """Calcula el histograma de un canal sin usar funciones de OpenCV.

    Parametros:
    canal (numpy.ndarray): canal 2D (HxW) con valores 0-255.
    bins  (int): numero de bins del histograma.

    Retorna:
    (hist, bin_edges) donde hist es el conteo por bin.
    """
    hist, edges = np.histogram(canal.flatten(), bins=bins, range=(0, 256))
    return hist, edges


def graficar_histograma(canal, titulo, ax):
    """Dibuja el histograma de un canal con linea vertical de la media."""
    hist, edges = calcular_histograma(canal)
    centros = (edges[:-1] + edges[1:]) / 2
    media = canal.mean()
    ax.bar(centros, hist, width=1.0, color='gray', alpha=0.7)
    ax.axvline(media, color='red', linestyle='--', linewidth=1.5,
               label=f'media = {media:.2f}')
    ax.set_title(titulo)
    ax.set_xlabel('Intensidad')
    ax.set_ylabel('Frecuencia')
    ax.set_xlim(0, 255)
    ax.legend()


def histogramas_imagen2(imagen, salida_dir=None):
    """Genera los histogramas de cada canal de color (BGR) y de la escala
    de grises (promedio aritmetico) de una imagen, con una linea vertical
    que indica la media de cada distribucion.

    Parametros:
    imagen     (str): ruta de la imagen a color.
    salida_dir (str): carpeta donde guardar el resultado. Por defecto
                      la misma carpeta de la imagen.

    Retorna:
    str: ruta del archivo de histograma guardado.
    """
    img = cv2.imread(imagen, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("No se pudo leer la imagen: " + str(imagen))

    b, g, r = cv2.split(img)

    # Escala de grises por promedio aritmetico (sin usar funciones de OpenCV)
    gris = (img[:, :, 0].astype(np.float64)
            + img[:, :, 1].astype(np.float64)
            + img[:, :, 2].astype(np.float64)) / 3.0
    gris = np.round(gris).astype(np.uint8)

    fig, axes = plt.subplots(2, 2, figsize=(12, 9))
    graficar_histograma(b, 'Canal Azul', axes[0, 0])
    graficar_histograma(g, 'Canal Verde', axes[0, 1])
    graficar_histograma(r, 'Canal Rojo', axes[1, 0])
    graficar_histograma(gris, 'Escala de Grises (promedio)', axes[1, 1])
    plt.tight_layout()

    if salida_dir is None:
        salida_dir = os.path.dirname(imagen)
    os.makedirs(salida_dir, exist_ok=True)
    base = os.path.splitext(os.path.basename(imagen))[0]
    salida = os.path.join(salida_dir, f"{base}_histogramas.png")
    plt.savefig(salida, dpi=120)
    plt.close(fig)
    print("Histogramas guardados en:", salida)
    return salida


if __name__ == "__main__":
    base_dir = os.path.dirname(os.path.abspath(__file__))
    imagen = os.path.join(base_dir, "imagen2", "imagen2_color.jpg")
    histogramas_imagen2(imagen)
