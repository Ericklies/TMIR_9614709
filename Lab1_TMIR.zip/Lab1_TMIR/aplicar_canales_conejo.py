import cv2
import os
from activar_canales import activar_canales


def aplicar_canales_conejo(imagen, colores=None, salida_dir=None):
    """Aplica la funcion activar_canales a una imagen en escala de grises 3D
    (conejo) para cada codigo de color, guardando los resultados.

    Parametros:
    imagen      (str): ruta de la imagen del conejo (gris 3D).
    colores    (list): lista de codigos de color a aplicar. Por defecto
                      [1, 2, 3, 10, 20, 30].
    salida_dir  (str): carpeta donde guardar los resultados. Por defecto
                      la misma carpeta de la imagen.

    Retorna:
    dict: {color: numpy.ndarray} con cada imagen modificada.
    """
    if colores is None:
        colores = [1, 2, 3, 10, 20, 30]

    if salida_dir is None:
        salida_dir = os.path.dirname(imagen)
    os.makedirs(salida_dir, exist_ok=True)

    # Convertir a BGR de 3 canales si la imagen tiene alpha (4 canales)
    img = cv2.imread(imagen, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise ValueError("No se pudo leer la imagen: " + str(imagen))
    if img.ndim == 3 and img.shape[2] == 4:
        img_bgr = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)
        base = os.path.splitext(os.path.basename(imagen))[0]
        tmp = os.path.join(salida_dir, f"{base}_bgr.png")
        cv2.imwrite(tmp, img_bgr)
        imagen_proc = tmp
    else:
        imagen_proc = imagen

    resultados = {}
    for color in colores:
        base = os.path.splitext(os.path.basename(imagen_proc))[0]
        ruta_salida = os.path.join(
            salida_dir, f"{base}_salida_color_{color}.jpg")
        res = activar_canales(imagen_proc, color)
        # Sobrescribir con el nombre deseado en salida_dir
        cv2.imwrite(ruta_salida, res)
        resultados[color] = res
        print(f"color {color}: guardado en {ruta_salida}")

    return resultados


if __name__ == "__main__":
    base_dir = os.path.dirname(os.path.abspath(__file__))
    imagen = os.path.join(base_dir, "conejo", "conejo_gris_3d.png")
    aplicar_canales_conejo(imagen)
