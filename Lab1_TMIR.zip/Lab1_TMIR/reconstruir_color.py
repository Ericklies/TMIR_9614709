import cv2
import numpy as np
import os


def construir_color(img_azul, img_verde, img_rojo):
    """Reconstruye una imagen a color a partir de sus 3 imagenes en escala
    de grises (una por canal).

    Parametros:
    img_azul (str): ruta de la imagen en gris correspondiente al canal azul.
    img_verde (str): ruta de la imagen en gris correspondiente al canal verde.
    img_rojo (str): ruta de la imagen en gris correspondiente al canal rojo.

    Retorna:
    numpy.ndarray: imagen BGR reconstruida.
    """
    b = cv2.imread(img_azul, cv2.IMREAD_GRAYSCALE)
    g = cv2.imread(img_verde, cv2.IMREAD_GRAYSCALE)
    r = cv2.imread(img_rojo, cv2.IMREAD_GRAYSCALE)

    if b is None or g is None or r is None:
        raise ValueError("No se pudieron leer una o mas imagenes.")

    if not (b.shape == g.shape == r.shape):
        raise ValueError("Las 3 imagenes deben tener las mismas dimensiones.")

    # OpenCV usa orden BGR: azul->0, verde->1, rojo->2
    color = cv2.merge([b, g, r])
    return color


def guardar_reconstruccion(directorio, nombre_base, salida_dir=None):
    """Reconstruye la imagen a color de un conjunto (azul, verde, rojo)
    dentro de 'directorio' y la guarda como <nombre_base>_color.jpg.

    Parametros:
    directorio   (str): carpeta que contiene las 3 imagenes en gris.
    nombre_base  (str): prefijo de los archivos (ej. 'imagen1').
    salida_dir   (str): carpeta donde guardar el resultado (por defecto
                        la misma del directorio).

    Retorna:
    numpy.ndarray con la imagen reconstruida.
    """
    azul = os.path.join(directorio, f"{nombre_base}_salida_gray_azul.jpg")
    verde = os.path.join(directorio, f"{nombre_base}_salida_gray_verde.jpg")
    rojo = os.path.join(directorio, f"{nombre_base}_salida_gray_rojo.jpg")

    color = construir_color(azul, verde, rojo)

    if salida_dir is None:
        salida_dir = directorio
    os.makedirs(salida_dir, exist_ok=True)
    salida = os.path.join(salida_dir, f"{nombre_base}_color.jpg")
    cv2.imwrite(salida, color)
    return color


if __name__ == "__main__":
    base_dir = os.path.dirname(os.path.abspath(__file__))
    conjuntos = [
        ("imagen1", "imagen1"),
        ("imagen2", "imagen2"),
        ("perro", "perro"),
    ]
    for carpeta, nombre in conjuntos:
        dir_path = os.path.join(base_dir, carpeta)
        resultado = guardar_reconstruccion(dir_path, nombre)
        print(f"{nombre}: reconstruida con shape {resultado.shape}")
