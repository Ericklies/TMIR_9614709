import cv2
import os


def activar_canales(imagen, color):
    """Activa los canales de color de una imagen segun el parametro color.

    Parametros:
    imagen (str): ruta de la imagen de entrada (leida en BGR con OpenCV).
    color  (int): codigo del canal o combinacion a conservar.
        1  -> azul
        2  -> verde
        3  -> rojo
        10 -> rojo y verde
        20 -> verde y azul
        30 -> azul y rojo

    Retorna:
    numpy.ndarray con la imagen modificada (canales no activos en 0).
    Ademas guarda el resultado en <nombre>_salida_color_<color>.jpg.
    """
    img = cv2.imread(imagen)
    if img is None:
        raise ValueError("No se pudo leer la imagen: " + str(imagen))

    # OpenCV usa orden BGR: 0=azul, 1=verde, 2=rojo
    conservar = {
        1:  {0},       # azul
        2:  {1},       # verde
        3:  {2},       # rojo
        10: {1, 2},    # rojo y verde
        20: {0, 1},    # verde y azul
        30: {0, 2},    # azul y rojo
    }

    if color not in conservar:
        raise ValueError(
            "color invalido. Valores validos: 1, 2, 3, 10, 20, 30")

    img_mod = img.copy()
    for c in range(3):
        if c not in conservar[color]:
            img_mod[:, :, c] = 0

    base = os.path.splitext(imagen)[0]
    salida = f"{base}_salida_color_{color}.jpg"
    cv2.imwrite(salida, img_mod)

    return img_mod


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Activa canales de color de una imagen.")
    parser.add_argument("imagen", help="ruta de la imagen de entrada")
    parser.add_argument("color", type=int, help="codigo de color (1,2,3,10,20,30)")
    args = parser.parse_args()

    resultado = activar_canales(args.imagen, args.color)
    print("Imagen procesada. Shape:", resultado.shape)
