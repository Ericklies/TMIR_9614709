import cv2
import numpy as np
import os


def gris_ponderado(imagen, salida_dir=None):
    """Convierte una imagen a escala de grises utilizando el enfoque
    ponderado BT.601 (luminancia): 0.299*R + 0.587*G + 0.114*B.

    Esta ponderacion refleja la sensibilidad del ojo humano, el cual
    percibe con mayor claridad el verde, luego el rojo y por ultimo el
    azul. Es el enfoque de escala de grises ponderado mas adecuado para
    imagenes naturales.

    Parametros:
    imagen     (str): ruta de la imagen de entrada.
    salida_dir (str): carpeta donde guardar el resultado. Por defecto
                      la misma carpeta de la imagen.

    Retorna:
    numpy.ndarray: imagen en escala de grises (2D, uint8).
    """
    img = cv2.imread(imagen, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise ValueError("No se pudo leer la imagen: " + str(imagen))

    # Convertir a BGR de 3 canales si tiene alpha (4 canales)
    if img.ndim == 3 and img.shape[2] == 4:
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

    # OpenCV usa BGR: B=0, G=1, R=2
    b = img[:, :, 0].astype(np.float64)
    g = img[:, :, 1].astype(np.float64)
    r = img[:, :, 2].astype(np.float64)

    # Ponderacion BT.601: 0.114*B + 0.587*G + 0.299*R
    gris = 0.114 * b + 0.587 * g + 0.299 * r
    gris = np.clip(gris, 0, 255).astype(np.uint8)

    if salida_dir is None:
        salida_dir = os.path.dirname(imagen)
    os.makedirs(salida_dir, exist_ok=True)
    base = os.path.splitext(os.path.basename(imagen))[0]
    salida = os.path.join(salida_dir, f"{base}_gris_ponderado.jpg")
    cv2.imwrite(salida, gris)
    print("Imagen en grises ponderado guardada en:", salida)
    return gris


if __name__ == "__main__":
    base_dir = os.path.dirname(os.path.abspath(__file__))
    imagen = os.path.join(base_dir, "conejo", "conejo_gris_3d.png")
    gris_ponderado(imagen)
